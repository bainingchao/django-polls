from django.contrib import admin

# Register your models here.
from .models import Question,Choice

class QuestionAdmin(admin.ModelAdmin):
   # fieldsets = [
        # ('问题内容', {'fields': ['question_text']}),
        # ('发布时间', {'fields': ['pub_data']}),
    # ]
    # fields = ['pub_data', 'question_text']
    list_display = ('question_text', 'pub_data')
    list_filter = ['pub_data'] # 过滤器

admin.site.register(Question, QuestionAdmin)


class ChoiceAdmin(admin.ModelAdmin):
    # fields = ['question','choice_text', 'votes']
    list_display = ('question','choice_text', 'votes')

admin.site.register(Choice, ChoiceAdmin)

